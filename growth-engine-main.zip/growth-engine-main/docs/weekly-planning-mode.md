# Weekly Planning Mode Spec

## Why This Exists

The current app is good at generating tweets from a single topic.

The real weekly job is broader:

- absorb market, product, and internal signals
- decide which narratives matter this week
- translate those narratives into a balanced 15-tweet plan
- draft tweets that fit both web3-native and web2-studio audiences
- avoid repetition while reinforcing a coherent point of view

This spec reframes the product from a `tweet generator` into a `weekly planning and drafting system`.

## Primary User Goal

Help the operator plan and draft 15 tweets for the week with:

- stronger narrative coherence
- faster Monday planning
- better balance across audience types
- tighter connection between source signals and final drafts
- fewer repetitive or overly crypto-native posts

## Product Principles

- planning should happen before drafting
- weekly narrative decisions should be visible and editable
- every tweet should have a job
- source material should stay attached to the draft it informs
- the tool should help balance conviction with accessibility
- the user should be able to draft one slot or all 15 at once

## Core User Flow

### 1. Weekly Input

The week starts with a structured intake step.

Inputs:

- `weeklyContextDump`: large freeform textarea for raw notes
- `marketMood`: bullish, cautious, risk-off, mixed
- `mustCover`: key developments that should appear this week
- `internalSignals`: product launches, signings, milestones, stats
- `priorityAccounts`: who we want to influence or respond to
- `thingsToAvoid`: narratives, words, or framing to avoid
- `targetMix`: optional weekly allocation across categories

Example use:

- paste Slack notes
- paste macro takeaways from Grok or The Block
- include product wins and data points
- note important web2-sensitive framing constraints

### 2. Weekly Synthesis

The tool converts the raw dump into a structured weekly brief.

Outputs:

- `marketSummary`
- `audienceTensions`
- `3-5 weekly narratives`
- `evidence bank`
- `open risks`
- `recommended weekly mix`

Each weekly narrative should include:

- `claim`
- `whyNow`
- `audience`
- `proofPoints`
- `toneGuidance`
- `tweetOpportunityCount`

### 3. Weekly Slot Plan

The tool proposes all 15 tweet slots at once.

Each slot should have:

- `slotNumber`
- `day`
- `category`
- `goal`
- `topic`
- `weeklyNarrativeId`
- `audienceLens`
- `web2Web3Balance`
- `evidence`
- `style`
- `priority`
- `status`

The user can edit the plan before drafting.

### 4. Bulk Drafting

The user can:

- draft one slot
- draft all empty slots
- regenerate a single slot
- regenerate all tweets tied to one weekly narrative

Each slot should produce:

- `primaryDraft`
- `variantPunchier`
- `variantSafer`
- `variantWeb2Friendly`

MVP can start with just `primaryDraft` plus one alternate.

### 5. Weekly Review

Before finalizing, the tool runs a weekly QA pass.

Checks:

- repeated hooks
- repeated claims
- overuse of one style
- too much overlap across adjacent slots
- too much crypto-native language
- not enough product or evidence-backed posts
- narrative imbalance across the week

The output should be a simple review panel with warnings and suggested fixes.

## Proposed Screen Layout

This should live as a new mode in the existing generator UI rather than replacing the current single-topic flow.

### Mode Toggle

At the top of `TweetGenerator.tsx`, add a second control:

- `Single Tweet Mode`
- `Weekly Planning Mode`

### Weekly Planning Mode Layout

Section 1: `Weekly Brief`

- large `Weekly Context Dump` textarea
- structured mini-fields for market mood, priority accounts, things to avoid, and must-cover items
- `Generate Weekly Narratives` button

Section 2: `Weekly Narratives`

- list of 3-5 narrative cards
- each card shows claim, proof points, target audience, and suggested number of tweets
- narrative cards are editable

Section 3: `15-Tweet Plan`

- table or card grid for all slots
- each row is one tweet slot
- editable fields for category, topic, narrative, style, audience lens, and status
- `Auto-fill week` button
- `Draft all slots` button

Section 4: `Draft Studio`

- one card per slot
- shows slot metadata plus draft variants
- `Regenerate this slot`
- `Copy`
- `Mark scheduled`

Section 5: `Weekly QA`

- review warnings
- narrative coverage summary
- style distribution
- audience balance summary

## Recommended Weekly Categories

Default 15-slot allocation:

- `4` narrative-setting
- `3` data credibility
- `3` product or ecosystem signal
- `3` market commentary
- `2` lighter or engagement posts

This should be editable, but the tool should start with a recommended mix.

## Recommended Audience Lenses

Each slot should explicitly target one primary lens:

- `crypto-native investor`
- `crypto founder/operator`
- `web2 game studio executive`
- `game growth/UA lead`
- `broad market observer`

Each slot should also include a framing slider:

- `web3-forward`
- `balanced`
- `web2-accessible`

This is important because the operator is trying to preserve conviction with crypto audiences while staying accessible to mainstream studios.

## Data Model

Suggested shared types for a future `src/utils/weeklyPlanning.ts` or `src/types/weeklyPlanning.ts`:

```ts
export type WeeklyCategory =
  | "narrative"
  | "data"
  | "product"
  | "market"
  | "engagement";

export type AudienceLens =
  | "crypto_investor"
  | "crypto_operator"
  | "web2_exec"
  | "growth_lead"
  | "market_observer";

export type BalanceMode = "web3_forward" | "balanced" | "web2_accessible";

export interface WeeklyInput {
  weekOf: string;
  weeklyContextDump: string;
  marketMood?: string;
  mustCover: string[];
  internalSignals: string[];
  priorityAccounts: string[];
  thingsToAvoid: string[];
  targetMix?: Partial<Record<WeeklyCategory, number>>;
  lastWeekLearnings?: string[];
}

export interface WeeklyNarrative {
  id: string;
  claim: string;
  whyNow: string;
  audience: AudienceLens[];
  proofPoints: string[];
  toneGuidance: string;
  tweetOpportunityCount: number;
}

export interface WeeklyPlanSlot {
  id: string;
  slotNumber: number;
  day?: string;
  category: WeeklyCategory;
  goal: string;
  topic: string;
  weeklyNarrativeId?: string;
  audienceLens: AudienceLens;
  balanceMode: BalanceMode;
  evidence: string[];
  tweetStyle: string;
  priority: "high" | "medium" | "low";
  status: "planned" | "drafted" | "approved" | "scheduled";
}

export interface WeeklyDraft {
  slotId: string;
  primaryDraft: string;
  variantPunchier?: string;
  variantSafer?: string;
  variantWeb2Friendly?: string;
  rationale: string;
  sourceTrace: string[];
}

export interface WeeklyReview {
  warnings: string[];
  repeatedThemes: string[];
  styleDistribution: Record<string, number>;
  categoryDistribution: Record<string, number>;
  audienceDistribution: Record<string, number>;
  improvementSuggestions: string[];
}
```

## Backend Shape

### New API Route

Add a new route:

- `src/app/api/weekly-planner/route.ts`

Suggested request stages:

- `synthesize`
- `plan`
- `draft_slot`
- `draft_all`
- `review`

Suggested request shape:

```ts
type WeeklyPlannerStage =
  | "synthesize"
  | "plan"
  | "draft_slot"
  | "draft_all"
  | "review";

interface WeeklyPlannerRequest {
  stage: WeeklyPlannerStage;
  weeklyInput: WeeklyInput;
  narratives?: WeeklyNarrative[];
  slots?: WeeklyPlanSlot[];
  slotId?: string;
}
```

### New Agent Helpers

Add the following to `src/utils/agents.ts` or split into a new weekly planner utility:

- `runWeeklySynthesisAgent`
- `runWeeklyNarrativePlanner`
- `runWeeklySlotPlanner`
- `runWeeklySlotDraftAgent`
- `runWeeklyReviewAgent`

Important design choice:

Do not replace the current belief/evidence/research/narrative/hook/draft pipeline.

Instead:

- keep the current pipeline for single-topic depth
- use the new weekly planner to decide the week
- let each slot optionally call a trimmed version of the current drafting flow

## Recommended Agent Flow

### Stage 1: Weekly Synthesis Agent

Input:

- weekly context dump
- structured weekly fields

Output:

- cleaned weekly brief
- 3-5 core narratives
- evidence bank
- audience tensions

Prompt objective:

- identify the few beliefs worth reinforcing this week
- separate transient news from durable narrative opportunities
- interpret internal signals in a market-shaping way

### Stage 2: Weekly Slot Planner Agent

Input:

- weekly narratives
- evidence bank
- target mix

Output:

- 15-slot weekly plan

Prompt objective:

- assign each slot a clear job
- balance categories and audiences
- avoid clustering similar tweets back-to-back

### Stage 3: Slot Drafter Agent

Input:

- one plan slot
- linked narrative
- evidence
- selected style
- optional exemplar tweets

Output:

- draft variants for that slot

Prompt objective:

- keep the tweet aligned with its weekly job
- match tone to the audience lens
- use web3 framing carefully when `balanceMode` is not `web3_forward`

### Stage 4: Weekly Review Agent

Input:

- all 15 slots and drafts

Output:

- repetition flags
- balance warnings
- improvement suggestions

Prompt objective:

- review the week as a portfolio, not 15 isolated tweets

## Guardrails

Add explicit prompt constraints for the weekly planner and drafter:

- do not over-index on token price commentary unless it supports a strategic point
- avoid framing that sounds like speculative hype to web2 studios
- prefer practical outcomes: growth, monetisation, margins, distribution, retention
- use web3 as infrastructure when appropriate, not always the headline
- preserve conviction without sounding defensive or evangelical
- each tweet should advance either narrative, credibility, or product perception

## Reuse From Existing System

The current app already has good building blocks:

- style selection
- content archetypes
- exemplar tweet retrieval
- agent-driven drafting
- editable intermediate outputs

The weekly mode should reuse those rather than starting over.

Most reusable pieces:

- `getExemplarsForStyle`
- `runTweetDrafter`
- the stage-card editing pattern in `TweetGenerator.tsx`
- the existing tweet style metadata in `generateFromOpenAI.ts`

## MVP Build Order

### Phase 1

Add weekly planning UI and local state only.

- weekly mode toggle
- weekly context dump
- manual 15-slot editor
- no new agents yet

Outcome:

- user can plan the week in the app, even before full automation

### Phase 2

Add synthesis and slot planning agents.

- weekly synthesis endpoint
- narrative cards
- auto-fill 15-slot plan

Outcome:

- Monday planning becomes much faster

### Phase 3

Add bulk drafting.

- draft one slot
- draft all empty slots
- regenerate by slot

Outcome:

- full planning-to-draft workflow lives in one place

### Phase 4

Add weekly QA and performance memory.

- last-week learnings input
- repetition checks
- audience balance checks

Outcome:

- better quality control across the whole week

## Suggested File Changes

Likely implementation path:

- update `src/components/TweetGenerator.tsx`
- add `src/app/api/weekly-planner/route.ts`
- extend `src/utils/agents.ts` or add `src/utils/weeklyPlanning.ts`
- add weekly planning types in `src/types/weeklyPlanning.ts`
- optionally add `src/components/WeeklyPlanner.tsx` to keep `TweetGenerator.tsx` manageable

## Success Criteria

The mode is working well if:

- the user can go from raw weekly notes to a 15-tweet plan in under 15 minutes
- each tweet clearly maps to a weekly narrative or strategic goal
- drafts are less repetitive than the current one-topic workflow
- web2-sensitive tweets sound more practical without losing conviction
- the tool helps plan the week, not just generate isolated copy
