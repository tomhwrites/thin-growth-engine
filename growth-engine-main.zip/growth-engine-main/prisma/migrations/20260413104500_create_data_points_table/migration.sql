CREATE TABLE IF NOT EXISTS "DataPoints" (
    "id" SERIAL NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "claim" TEXT NOT NULL,
    "category" TEXT NOT NULL,
    "belief" TEXT NOT NULL DEFAULT '',
    "tags" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "sourceUrl" TEXT NOT NULL DEFAULT '',
    "sourceType" TEXT NOT NULL DEFAULT 'agent',
    "asOfDate" TIMESTAMP(3),
    "confidence" INTEGER NOT NULL DEFAULT 3,
    "archived" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "DataPoints_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "DataPoints_category_archived_idx"
ON "DataPoints"("category", "archived");
