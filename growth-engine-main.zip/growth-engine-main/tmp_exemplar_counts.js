const { PrismaClient } = require("@prisma/client");

const prisma = new PrismaClient();

async function main() {
  const byTopic = await prisma.exemplarTweets.groupBy({
    by: ["content_topic"],
    _count: { _all: true },
    where: { archived: false },
    orderBy: [{ _count: { content_topic: "desc" } }, { content_topic: "asc" }],
  });

  const byStyle = await prisma.exemplarTweets.groupBy({
    by: ["tweet_style"],
    _count: { _all: true },
    where: { archived: false },
    orderBy: [{ _count: { tweet_style: "desc" } }, { tweet_style: "asc" }],
  });

  console.log(JSON.stringify({ byTopic, byStyle }, null, 2));
}

main()
  .catch((error) => {
    console.error(error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
